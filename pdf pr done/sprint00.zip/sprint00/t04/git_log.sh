git log --pretty=tformat:"%t %s" -3


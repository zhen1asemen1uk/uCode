touch -t 199108240000.00 fire
chmod 400 fire


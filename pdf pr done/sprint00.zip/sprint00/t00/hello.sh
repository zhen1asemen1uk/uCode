touch greeting.txt
echo Hello, superhero! > greeting.txt

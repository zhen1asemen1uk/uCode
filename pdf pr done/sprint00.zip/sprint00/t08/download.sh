curl $1 > $2

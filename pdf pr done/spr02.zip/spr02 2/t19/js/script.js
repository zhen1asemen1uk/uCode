
function checkBrackets(str){
    for(let = i; i< str.length; i++){
    if(str != "(" || str != ")"){
} else {

}
}
}


console.log(checkBrackets('1)()(())2(()'));
// 2
console.log(checkBrackets(NaN));
// -1
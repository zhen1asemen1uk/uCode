function myFunc() {
    alert("Freedom is power");
}
myFunc();
 let number = 2;
function countMySquare(number) { 
    return  number * number;
}
alert("The square of " + number + " = " + countMySquare(number));
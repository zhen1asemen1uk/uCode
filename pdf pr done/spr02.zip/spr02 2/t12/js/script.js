let a ="";
for (i = 0; i < 7; i++) {
  for (b = 0; b < i; b++) {
   a += "*";
  }
  a += "\n"
}
alert(a);

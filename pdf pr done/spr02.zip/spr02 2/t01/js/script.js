let z = 'Hello JavaScript from outside!';
alert(z);
// Змінну в JS можна оголосити з допомогою "let", "var" або "const".
// Наприклад: let a = 'Hello JavaScript' і т. д.
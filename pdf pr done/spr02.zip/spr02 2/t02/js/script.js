var quote;
alert(quote);
quote = "With great power, comes great responsibility.";
alert(quote);
function displayAuthor(){
var author = "Spiderman"; 
alert(author);
quote = "...";
}
displayAuthor();
alert(quote) ;

let a = prompt("Введіть число від 1 до 4: ");

function one(a) {
    let x = 0;

    if (a == 1) {
        return x = a * 2 / "a";
    } else if (a == 2) {
        return x = a * 1 / 0;
    } else if (a == 3) {
        return x = 0 * Infinity;
    } else if (a == 4) {
        return x = a * 40000000 == Infinity;
    } else if (a < 1 || a > 4) {
        return ("Wrong imput");
    } else {
        return ("Wrong imput");
    }
}
alert(one(a));